<?
	$_required = true;
	include_once "config.php";

//    $Ignite_id = $_POST[id];
	$Ignite_name = $_POST[name];
	$Ignite_email = $_POST[email];
    $Ignite_select = $_POST[status];
	

//$query  = "SELECT COUNT(*) as cnt FROM Ignite_form WHERE Ignite_id = '$id'" ;
//	$row = sql_fetch( $query ) ;


	sql_query("INSERT INTO `Ignite_form`(`Name`, `Email`, `Status`) VALUES ('$Ignite_name','$Ignite_email',' $Ignite_select')");

	alert("Submitted!","index.php"); // changed to index.php
	exit() ;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

</body>
</html>