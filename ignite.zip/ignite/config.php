<?
if (!$_required) {
	header("HTTP/1.0 404 Not Found");
	exit;
}

/* REDIRECT */

if (strpos($_SERVER[HTTP_HOST], 'www.') !== false) {
	$url = str_replace('www.', '', $_SERVER[HTTP_HOST]);

	header("Location: http://".$url.$_SERVER[REQUEST_URI]);
}

/* DB CONNECTION */
$mysql[host] = 'localhost';
$mysql[user] = 'ignijvso';
$mysql[password] = 'Ko4j3hUPAtjJ';
$mysql[database] = 'ignijvso_Ignite';

$connect = @mysql_connect("$mysql[host]","$mysql[user]","$mysql[password]") or die('CONNECTION FAILED');
@mysql_select_db("$mysql[database]") or die('DB SET FAILED');
mysql_query("SET NAMES 'utf8'");
mysql_query("SET CHARACTER SET 'utf8'");
$mysqli = new mysqli($mysql[host], $mysql[user], $mysql[password], $mysql[database]);
$mysqli->set_charset('utf8');

/* ANTI SQL-INJECTION */
if(get_magic_quotes_gpc()) {
	$_GET  = array_map("stripslashes", $_GET);
	$_POST = array_map("stripslashes", $_POST);
}
$_GET  = array_map("cleanup", $_GET);
$_GET  = array_map("mysql_real_escape_string", $_GET);
$_POST = array_map("cleanup", $_POST);
$_POST = array_map("mysql_real_escape_string", $_POST);

/* FUNCTIONS LIBRARY */
function cleanup($str) {
	return strip_tags(htmlspecialchars($str, ENT_QUOTES));
}

function alert($msg, $url=null) {
	// header('Content-Type:text/html;charset=utf-8');
	$str = $url ? "document.location.href = '$url';" : "history.back();";
	print "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' /><script>alert('$msg'); $str </script>";
	exit;
}

function sql_query($sql, $error=TRUE) {
    if ($error)
        $result = @mysql_query($sql) or die("<p>$sql</p><p>" . mysql_errno() . " : " .  mysql_error() . "</p><p>error file : $_SERVER[PHP_SELF]</p>");
    else
        $result = @mysql_query($sql);
    return $result;
}

function sql_fetch($sql, $error=TRUE) {
    $result = sql_query($sql, $error);
    $row = sql_fetch_array($result);
    return $row;
}

function sql_fetch_array($result) {
    $row = @mysql_fetch_assoc($result);
    return $row;
}


?>