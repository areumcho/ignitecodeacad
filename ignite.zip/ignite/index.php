<?
	$_required = true;
	include_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href='http://fonts.googleapis.com/css?family=Bitter' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" type="text/css" href="./css/grid.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css">
    <link rel="stylesheet" type="text/css" href="./css/ionicons.min.css">
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <script type="text/javascript" src="script.js"></script>
    <script src="jquery.min.js"></script>
    <meta charset="UTF-8">
    <title>Ignite</title>

    <script>
        $(document).ready(function() {

            $('.nav-hello').click(function() {
               // var headerTop = $('.header').offset().top;
                $('html,body').animate({
                    scrollTop: 0
                }, 1000);
            });
            $('.nav-mission').click(function() {
                var missionTop = $('.section-mission').offset().top;
                $('html,body').animate({
                    scrollTop: missionTop
                }, 1000);
            });
            
               $('.nav-schedule').click(function() {
                var scheduleTop = $('.section-schedule').offset().top;
                $('html,body').animate({
                    scrollTop: scheduleTop
                }, 1000);
            });
            
            $('.nav-findus').click(function() {
                var findUsTop = $('.section-findus').offset().top;
                $('html,body').animate({
                    scrollTop: findUsTop
                }, 1000);
            });
            
            $('header .bar').click(function(){
               $('.m_navi-bar').slideToggle('slow'); 
            });
            
            $('.m_navi-bar').hover(function(){
                $(this).show();
            },function(){
                $(this).hide();
            });
            
            $(window).scroll(function(){
                var headH = $('header').height();
                
                if( $(this).scrollTop() > headH){
                   $('header nav').css({'position':'fixed','top':'0','background':'green'});
                }
                else{
                    $('header nav').css({'position':'static','background':'none'});
                }
            });
        });
        
        
        
    function checkForm(form)
    {
    if(!form.terms.checked) {
      alert("Please indicate that you are 13 or above");
      form.terms.focus();
      return false;
    }
    return true;
  }
        
    </script>

</head>
<body>
    <header>
        <nav>
            <img class="logo" src="img/logo2.png">
            <div class="navi-bar">
                <ul>
                    <li class="nav-hello">HOME</li>
                    <li class="nav-mission">MISSION</li>
                    <li class="nav-schedule">SCHEDULE</li>
                    <li class="nav-findus">CONTACT US</li>
                </ul>
            </div>
            <div class="bar"><img src="img/menu2.png"></div>
            <!-- Mobile version navi-->
            
            <div class="m_navi-bar">
                <ul>
                    <li class="nav-hello">HOME</li>
                    <li class="nav-mission">MISSION</li>
                    <li class="nav-schedule">SCHEDULE</li>
                    <li class="nav-findus">CONTACT US</li>
                </ul>
            </div>
            
            
        </nav>
        <div class="row wrapper">
            <h1>Come get your <br>digital literacy on!</h1>
        </div>
        <div class="row wrapper">
            <div class="left">
                <h2>Join the #WuTechClan!</h2>
                <p>The Ignite Tech Academy wants to bring the tech to you. If you are interested in learning more about the world of technology in a casual laid back environment, come hang out with us in F Building on Saturdays!</p>
            </div>
            <div class="right">
                <div class="form-style-10">
                    <h1>Sign Up Now!<span>Sign up and attend a free coding wokshop</span></h1>
                    <form action="join_ok.php" method="POST" onsubmit="return checkForm(this);">
                        
                        <div class="inner-wrap">
                            <label>Your Full Name <input type="text" name="name" required /></label>
                            <label>Email Address <input type="email" name="email" required/></label>
                            <label>I am a(n)...*</label>
                            <select id="select-bar" name="status">
                            <option value="select" id="select">----Please Select One----</option>
                            <option value="algonquin">Algonquin College Student</option>
                            <option value="other">Other School Student</option>
                            <option value="faculty">Faculty member</option>
                            <option value="community">Community Memeber</option>
                          </select>
                          <p id="age-val"><input type="checkbox" name="terms"> I am 13 years old or older</p>
                          
                          
                        </div>
                        <div class="button-section">
                            <input type="submit" name="Sign Up" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </header>
    <section class="section-mission js-section-mission">
        <div class="row wrapper">
            <h1>The workshop is <br> open for everyone!</h1>
        </div>
        <div class="row wrapper">
            <div class="col span-1-of-3">
                <img src="img/tech.png">
                <div class="contents">
                    <blockquote><span>Our Mission</span><br> Ignite Technology Academy is dedicated to expanding access to technology and computer science by increasing participation amongst college students, faculty, staff, alumni and community.
                    </blockquote>
                </div>
            </div>
            <div class="col span-1-of-3">
                <img src="img/goal.jpg">
                <div class="contents">
                    <span>Our goal</span><br> Our goal is to facilitate a technology-based program that is accessible to all interested parties who want to learn about emerging technologies, computer science and coding.

                </div>
            </div>
            <div class="col span-1-of-3">
                <img src="img/student.jpg">
                <div class="contents">
                    <span>Algonquin Student</span><br>Participation will add hours to the co-curriculum on their transcript but that is only for Algonquin students.

                </div>
            </div>
        </div>

    </section>
    
    
    <hr>
    <section class="section-schedule">
       
    
        <div class="row wrapper">
            <h1>Be ready for our first<br> workshop in October</h1>
        </div>
        <img src="/img/soon.jpg">

<!--
        <div class="row wrapper">
            <div class="col span-1-of-2">
                <img src="#">
                <div class="contents">
                    
                </div>
            </div>
            <div class="col span-1-of-2">
                <img src="#">
                <div class="contents">
                   
                </div>
          
            </div>
        </div>
-->



    </section>
    
    
    
    <section class="section-findus js-section-findus">
        <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2804.0250954985477!2d-75.75843424933184!3d45.34830567899717!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cce071ee7d7f997%3A0x5547a440a81b0550!2sAlgonquin+College!5e0!3m2!1sen!2sca!4v1505721385663" frameborder="0" style="border:0" allowfullscreen></iframe>
    </section>
    <footer>
        <div class="row">
            <ul class="social-links">
                <li><a href="https://www.facebook.com/igniteacad"><i class="ion-social-facebook"></i></a></li>
                <li><a href="https://twitter.com/igniteacad"><i class="ion-social-twitter"></i></a></li>
                <li><a href="mailto:ignitetechacademy@gmail.com"><i class="ion-email"></i></a></li>
                <li><a href="https://www.instagram.com/igniteacad/"><i class="ion-social-instagram"></i></a></li>
            </ul>
        </div>
        <div class="row">
            <p>
                Copyright &copy; 2017 by Ignite Tech Academy. All rights reserved.
            </p>
        </div>

    </footer>

</body>
</html>