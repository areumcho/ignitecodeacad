<?
	$_required = true;
	include_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	
	
</head>
<body>
	<form action="join_ok.php" method="POST">
		<div>
			<input type="text" name="id" placeholder="아이디" maxlength="10" required>
		</div>
		<div>
			<input type="password" name="pw" placeholder="비밀번호" minlength="10" required class="pw">
		</div>
		<div>
			<input type="password" name="pw_ok" placeholder="비밀번호확인" required class="pw_ok">
		</div>
		<div>
			<input type="text" name="name" placeholder="이름" required>
		</div>
		<div>
			<input type="reset" value="리셋">
			<input type="submit" value="완료" class="clear">
		</div>
	</form>

</body>
</html>